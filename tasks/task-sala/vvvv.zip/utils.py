import numpy as np
import cv2 as cv

BGR_RED_SLICE = np.s_[:, :, 2]
BGR_GREEN_SLICE = np.s_[:, :, 1]
BGR_BLUE_SLICE = np.s_[:, :, 0]

